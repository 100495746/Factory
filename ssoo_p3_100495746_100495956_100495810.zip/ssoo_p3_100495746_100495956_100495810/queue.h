#ifndef QUEUE_H
#define QUEUE_H

#include <pthread.h>

// Structure to hold an element in the queue
struct element {
    int num_edition;
    int id_belt;
    int last;
};

// Structure representing the queue itself
struct queue {
    struct element* elements;
    int size;
    int head;
    int tail;
    int count;
    pthread_mutex_t mutex;
    pthread_cond_t not_full;
    pthread_cond_t not_empty;
};

// Function declarations
int queue_init(struct queue* q, int size);
int queue_destroy(struct queue* q);
int queue_put(struct queue* q, struct element* elem);
struct element* queue_get(struct queue* q);
int queue_empty(struct queue* q);
int queue_full(struct queue* q);

#endif // QUEUE_H
