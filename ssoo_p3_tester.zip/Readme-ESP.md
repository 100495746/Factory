# Instrucciones para la ejecución de tester.sh


## Directorios importantes
1. ExpectedOutputs: conjunto de ficheros con la salida esperada por el programa factory, contra el que se compara la salida del alumno.
2. InputFiles: conjunto de ficheros de entrada para el programa factory.
3. MyOutputs: salidas generadas por el programa factory del alumno.

## Ejecución
```bash
bash tester.sh ssoo_p3_NIA1_NIA2_NI3.zip
```